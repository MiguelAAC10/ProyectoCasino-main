<?php

return[
    "Update" => "Actualizar",
    "Delete" => "Eliminar",
    "Save" => "Guardar",
    "Create" => "Añadir ",
    "Materiaps" => "Ingrediente",
    "Create Materiap" => "Añadir Ingrediente",
    "Create Platillos" => "Añadir Platillo",
    "Create Clasificaciones" => "Añadir Clasificación",
    "Create Unidadesmeding" => "Añadir Unidades de Medida (Platillos)",
    "Create Unidadesmedida" => "Añadir Unidades de Medida (Ingredientes)",
    "Unidadesmedings" => "Unidades de Medida (Platillos)",
    "Unidadesmedidas" => "Unidades de Medida (Ingredientes)"
];